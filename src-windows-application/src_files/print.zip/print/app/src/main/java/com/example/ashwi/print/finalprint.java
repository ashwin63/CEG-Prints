package com.example.ashwi.print;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.renderscript.ScriptGroup;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.FilenameUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.util.Scanner;

import org.apache.commons.io.FilenameUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class finalprint extends AppCompatActivity {
    TextView response;
    String path = "";
    String ip = "192.168.0.110";
    String ipaddress;
    int port = 7777;
    boolean finished=false;
    RadioButton radioButton;
    //ProgressBar progressbar;
EditText copies1;
RadioGroup rgroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalprint);
        path = getIntent().getExtras().getString("Value1");
        ipaddress = getIntent().getExtras().getString("ipip");
       // progressbar.setVisibility(ProgressBar.GONE);
    copies1=(EditText)findViewById(R.id.copies);
        rgroup=(RadioGroup)findViewById(R.id.radioGroup);
    }

    public void sendserver(View view) {
        try {
           // progressbar= (ProgressBar) findViewById(R.id.progressBar);
            //progressbar.setVisibility(View.VISIBLE);
            int copies2=Integer.parseInt(String.valueOf(copies1.getText()));
            int selectedId = rgroup.getCheckedRadioButtonId();
            radioButton = (RadioButton) findViewById(selectedId);
            int colour=(radioButton.getText().equals("black")==true)?1:0;
            Toast.makeText(this, "the received ip is "+ipaddress+"  check "+ip, Toast.LENGTH_SHORT).show();


            downloadclient myClient = new downloadclient(ip, path, port,copies2,colour, response);
            myClient.execute();
            //......................................



        } catch (Exception e) {
            AlertDialog alertDialog = new AlertDialog.Builder(finalprint.this).create();
            alertDialog.setTitle("Server Busy");
            alertDialog.setMessage("Server is currently in use\nPlease Try Again after few minutes:");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }

private void finished()
{
    Intent i=new Intent(this,MainActivity.class);
    startActivity(i);
}

    private class downloadclient extends AsyncTask<Void, Void, String> {

        String dstAddress;
        int dstPort;
        String response = "";
        //TextView textResponse;
        String filepath = "";
        int copies;
        int color;
         String globalprotocol = "";

        downloadclient(String addr, String filepath1, int port,int tcopies,int tcolor, TextView textResponse) {
            dstAddress = addr;
            dstPort = port;
            filepath = filepath1;
            copies=tcopies;
            color=tcolor;
            //  this.textResponse = textResponse;
        }
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
          //  progressbar.setVisibility(ProgressBar.VISIBLE);
        }


        @Override
        protected String doInBackground(Void... arg0) {

            Socket socket = null;
            try {
                Log.i("filepath", filepath);
                socket = new Socket(dstAddress, dstPort);
                //now write function to transfer the whole file
                socket.setTcpNoDelay(true);
                BufferedOutputStream output;
                output = new BufferedOutputStream(socket.getOutputStream());

                InputStream geek = socket.getInputStream();
                //.........................................
                //send the  protocol
                File ffile = new File(filepath);
                String fileType = "";
                fileType = FilenameUtils.getExtension(filepath);
                Log.i("typetype", fileType);
                int sendcode = 0;
                switch (fileType) {
                    case "pdf":
                        sendcode = 5;
                        break;
                    case "text":
                        sendcode = 1;
                        break;
                    case "jpeg":
                        sendcode = 2;
                        break;
                    case "jpg":
                        sendcode = 2;
                        break;

                    case "png":
                        sendcode = 2;
                        break;
                    case "docx":
                        sendcode = 4;
                        break;
                    default:
                        sendcode = 1;

                }
                Log.i("filetypetest", fileType);
                String protocol = "AMEN/::/1.1/::/" + sendcode + "/::/"+copies+"/::/"+color+"/::/";
                byte[] array = protocol.getBytes();
                System.out.println(array);
                System.out.println("Available bytes in file: " + array.length);
                output.write(array);
                output.flush();
                InputStream input = new FileInputStream(new File(filepath));
                System.out.println("here Available bytes in file: " + input.available());
                int data = input.read();
                while (data != -1) {
                    //do something with data...
                    System.out.println(data);
                    output.write(data);
                    output.flush();
                    data = input.read();
                }

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "IOException: " + e.toString();
            } finally {
                if (socket != null) {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            //textResponse.setText(response);
            super.onPostExecute(result);
            try {
            //    progressbar.setVisibility(View.GONE);
                finished();
            }
            catch (Exception e)
            {
                Log.i("exe",e.toString());
            }
        }

    }
}