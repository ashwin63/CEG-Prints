
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.renderscript.ScriptGroup;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.apache.commons.io.FilenameUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.util.Scanner;

public class downloadclient extends AsyncTask<Void, Void, String> {

    String dstAddress;
    int dstPort;
    String response = "";
    //TextView textResponse;
    String filepath="";
int tcopies;
int tcolor;
    static String globalprotocol="";
    downloadclient(String addr, String filepath1, int port,int copies,int color, TextView textResponse) {
        dstAddress = addr;
        dstPort = port;
        filepath=filepath1;
        tcopies=copies;
        tcolor=color;
      //  this.textResponse = textResponse;
    }

    @Override
    protected String doInBackground(Void... arg0) {

        Socket socket = null;
        try {
            Log.i("filepath",filepath);
            socket = new Socket(dstAddress, dstPort);
            //now write function to transfer the whole file
            socket.setTcpNoDelay(true);
            BufferedOutputStream output;
            output = new BufferedOutputStream(socket.getOutputStream());

            InputStream geek = socket.getInputStream();
            //.........................................
            //send the  protocol
            File ffile=new File(filepath);
            String fileType="";
            fileType = FilenameUtils.getExtension(filepath);
            Log.i("typetype",fileType);
            int sendcode=0;
            switch(fileType)
            {
                case "pdf":sendcode=5;
                    break;
                case "text":sendcode=1;
                    break;
                case "jpeg":sendcode=2;
                    break;
                case "jpg":sendcode=2;
                    break;

                case"png":sendcode=2;
                    break;
                case "docx":sendcode=4;
                    break;
                default:sendcode=1;

            }
            Log.i("filetypetest",fileType);
            String protocol="AMEN/::/1.1/::/"+sendcode+"/::/"+tcopies+"/::/"+tcolor+"/::/";
            byte[]array=protocol.getBytes();
            System.out.println(array);
            System.out.println("Available bytes in file: "+array.length);
            output.write(array);
            output.flush();
            InputStream input = new FileInputStream(new File(filepath));
            System.out.println("here Available bytes in file: "+input.available());
            int data = input.read();
            while(data != -1) {
                //do something with data...
                System.out.println(data);
                output.write(data);
                output.flush();
                data = input.read();
            }

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "IOException: " + e.toString();
        } finally {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return response;
    }
    @Override
    protected void onPostExecute(String result) {
        //textResponse.setText(response);
        super.onPostExecute(result);
    }

}