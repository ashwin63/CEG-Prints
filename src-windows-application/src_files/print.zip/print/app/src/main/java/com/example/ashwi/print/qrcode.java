package com.example.ashwi.print;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.blikoon.qrcodescanner.QrCodeActivity;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

public class qrcode extends AppCompatActivity {
    private static final int REQUEST_CODE_QR_SCAN = 101;
String path="";
String ipaddress="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);
        path = getIntent().getExtras().getString("Value1");
        ipaddress=getIntent().getExtras().getString("ipip");
        onClick();

    }

    public void onClick() {
        Intent i = new Intent(qrcode.this, QrCodeActivity.class);
        startActivityForResult(i, REQUEST_CODE_QR_SCAN);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        try {
            if (resultCode != Activity.RESULT_OK) {
                Log.d("tagtag", "COULD NOT GET A GOOD RESULT.");
                if (data == null)
                    return;
                //Getting the passed result
                String result = data.getStringExtra("com.blikoon.qrcodescanner.error_decoding_image");
                if (result != null) {
                    AlertDialog alertDialog = new AlertDialog.Builder(qrcode.this).create();
                    alertDialog.setTitle("Scan Error");
                    alertDialog.setMessage("QR Code could not be scanned");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                return;

            }
            if (requestCode == REQUEST_CODE_QR_SCAN) {
                if (data == null)
                    return;
                //Getting the passed result
                String result = data.getStringExtra("com.blikoon.qrcodescanner.got_qr_scan_relult");
                Log.d("tagtag", "Have scan result in your app activity :" + result);
                String checkresult = "123456789";
                String dater = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                checkresult += dater;
                if (result.equals(checkresult)) {

                    Intent i;
                    i = new Intent(qrcode.this, finalprint.class);
                    i.putExtra("Value1", path);
                    i.putExtra("ipip", ipaddress);
                    startActivity(i);
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(qrcode.this).create();
                    alertDialog.setTitle("Scan Error");
                    alertDialog.setMessage("Please Try Again: "+result+"expected resu "+checkresult);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent i;
                                    i = new Intent(qrcode.this, qrcode.class);
                                    i.putExtra("Value1", path);
                                    i.putExtra("ipip", ipaddress);
                                    startActivity(i);
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                //AlertDialog alertDialog = new AlertDialog.Builder(qrcode.this).create();
                //alertDialog.setTitle("Scan result");
                //alertDialog.setMessage(result);
                //alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                //      new DialogInterface.OnClickListener() {
                //        public void onClick(DialogInterface dialog, int which) {
                //          dialog.dismiss();
                //    }
                //});
                //alertDialog.show();

            }
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
        }
    }
    @Override
    public void onBackPressed()
    {
        Intent i=new Intent(qrcode.this,MainActivity.class);
        startActivity(i);
    }
}
