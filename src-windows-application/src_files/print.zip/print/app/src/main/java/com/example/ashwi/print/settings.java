package com.example.ashwi.print;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class settings extends AppCompatActivity {

    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        editText=(EditText)findViewById(R.id.editText);
    }
    public void changer(View view) {
        String ip = editText.getText().toString();
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.ashwi.print", Context.MODE_PRIVATE);
        sharedPreferences.edit().putString("ipaddress", ip);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Setttings Successfully Changed !");
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent i = new Intent(settings.this, MainActivity.class);
                        startActivity(i);
                    }
                });


        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    @Override
    public void onBackPressed()
    {
        Intent i = new Intent(settings.this, MainActivity.class);
        startActivity(i);
    }
}
