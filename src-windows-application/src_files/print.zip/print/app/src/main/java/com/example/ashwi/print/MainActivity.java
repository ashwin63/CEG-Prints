package com.example.ashwi.print;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.io.File;

import yogesh.firzen.filelister.FileListerDialog;
import yogesh.firzen.filelister.OnFileSelectedListener;

public class MainActivity extends AppCompatActivity {

    String ipvalue="";

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
         super.onOptionsItemSelected(item);
         switch(item.getItemId())
         {
             case R.id.settings:
                 Intent i=new Intent(MainActivity.this,settings.class);
                 startActivity(i);
                 return true;

             case R.id.help:return true;
             default: return false;
         }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SharedPreferences sharedPreferences = this.getSharedPreferences("com.example.ashwi.print", Context.MODE_PRIVATE);
        ipvalue = sharedPreferences.getString("ipaddress", "default");
        if (ipvalue.equals("default"))
        {
            sharedPreferences.edit().putString("ipaddress","192.168.1.2");
            ipvalue="192.168.1.2";
        }
        android.support.v7.widget.Toolbar toolbar= (android.support.v7.widget.Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

    }
    public void fileopener(View view)
    {

        try {
            FileListerDialog fileListerDialog = FileListerDialog.createFileListerDialog(this);
            fileListerDialog.show();

            fileListerDialog.setOnFileSelectedListener(new OnFileSelectedListener() {
                @Override
                public void onFileSelected(File file, String path) {
                    //your code here
                    Intent i;
                    i = new Intent(MainActivity.this, qrcode.class);
                    i.putExtra("Value1", path);
                    i.putExtra("ipip",ipvalue);
                    startActivity(i);
                    //...............
                }
            });
        }
        catch (Exception e)
        {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onBackPressed()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            this.finishAffinity();
        }
        else
        {
            System.exit(0);
        }
    }
}
